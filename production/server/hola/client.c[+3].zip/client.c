#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

#include <sys/stat.h>
#include <sys/types.h>

#include "message.h"
#include "socket.c"


void send_file(int soc, char* filename, int size)
{
    struct sync_message m;
    strncpy(m.filename, filename, 1000);
    int j = 0, bytesRead = 0;
    FILE *fp = fopen(filename,"rb");
    if (fp != NULL)
    {
        while (j < size)
        {
            bytesRead = fread(m.fileBuff, 1, 1024, fp) ;
            m.size = bytesRead ;
            Writen(soc, &m, sizeof(m)); 
            j += 1024;
        }
    }
    fclose(fp);
}



int main(int argc , char *argv[])
{
    int sock;
    struct sockaddr_in server;
    char message[2000] , server_reply[2000];
    
    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1) 
    {
        printf("Could not create socket");
    }
    puts("Socket created");
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons( 8888 );
    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0) 
    {
        perror("connect failed. Error");
        return 1;
    }
    puts("Connected\n");
    //keep communicating with server
    char *names[] = {"jose.txt", "document.pdf", "patito.jpg", "naranjo.txt"} ;
    struct stat fileStat;

    int i;
    for (i = 0; i < 4; i++)
    {
        
        if(stat(names[i],&fileStat) < 0) return 1;
        
        struct sync_message m;
        struct file_sync_message response ;
        m.size = fileStat.st_size;
        strncpy(m.filename, names[i], 1000);

        Writen(sock, &m, sizeof(m));
        
        
        int n = Readn(sock, &response, sizeof(response));
        printf("%i\n", response.empty_directory) ;
        
        
        
        /*
        if( recv(sock , server_reply , 2000 , 0) < 0) {
            puts("recv failed");
            break;
        }
        printf("Server reply %s\n", server_reply); */
       
        
        /*
        //  ENVIAR ARCHIVOS AL SERVIDOR ====================================
        int j = 0, bytesRead = 0;
        unsigned char fileBuff[1024];
        FILE *fp = fopen(names[i],"rb");
        if (fp != NULL)
        {
            while (j < fileStat.st_size)
            {
                bytesRead = fread(m.fileBuff, 1, 1024, fp) ;
                m.size = bytesRead ;
                printf("Se leyó -> %i para %s\n", bytesRead, names[i]);
                Writen(sock, &m, sizeof(m)); 
                j += 1024;
            }
        }
        fclose(fp);
        //  ================================================================
        */
        send_file(sock, names[i], fileStat.st_size);
    } 

    close(sock);
    
    return 0;
}