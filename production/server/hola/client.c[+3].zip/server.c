
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>


#include "message.h"
#include "socket.c"


void get_file(int soc, struct sync_message received_packet, int filesize)
{
    int j = 0 ;
    FILE *fp = fopen(received_packet.filename,"ab") ;
    if (fp == NULL) printf("ERRRRRO AL ABRIR EL ARCHIVO") ;
    while ( j < filesize )
    {
        int bytesReceived = Readn(soc, &received_packet, sizeof(received_packet ) ) ;
        j += 1024 ;
        fwrite( received_packet.fileBuff, 1, received_packet.size, fp ) ;
    }
    fclose(fp);
}



int main(int argc , char *argv[]) 
{
    int socket_desc , client_sock , c , read_size;
    struct sockaddr_in server , client;
    char client_message[2000];

    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    
    puts("Socket created");
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( 8888 );
    
    
    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server, sizeof(server)) < 0) 
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
    
    
    //Listen
    listen(socket_desc , 3);
    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);

    //accept connection from an incoming client
    client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
    
    
    if (client_sock < 0) 
    {
        perror("accept failed");
        return 1;
    }
    puts("Connection accepted");
    
    struct sync_message received_packet ;
    struct file_sync_message response ;
	int received_packet_size = sizeof(received_packet);
	char filename[1000];
	int filesize;
	
	for (; ;)
	{
	    int n = Readn(client_sock, &received_packet, received_packet_size);
	    
	    if (n > 0)
	    {
	        strncpy(filename, received_packet.filename, strlen(received_packet.filename));
	        filesize = received_packet.size ;
	        if (received_packet.size == 12)
    	    {
    	        send(client_sock , received_packet.filename , strlen(received_packet.filename),0);
    	        printf("Hola %s desde el server\n", filename);
    	    }
    	    else
    	    {
    	        response.empty_directory = 1 ;
    	        Writen(client_sock, &response, sizeof(response));
    	        //send(client_sock, "No es 12", 255, 0);
    	        
    	    }
	    } else if (n == 0)
	    {
	        puts("Client disconnected");
	        fflush(stdout);
	        break;
	    } else if (read_size == -1)
	    {
	        perror("Failed at receiving");
	    }
	    
	    
	    /*
	    //  RECIBIR ARCHIVOS DESDE EL CLIENT ===================================
	    printf("Lo que viene para %s de tamaño %i \n", filename, filesize);
	    unsigned char fileBuff[1024] = {0};
        int j = 0, bytesReceived = 0;
        FILE *fp = fopen(received_packet.filename,"ab");
        if (fp == NULL) printf("ERRRRRO AL ABRIR EL ARCHIVO");
        while (j < filesize)
        {
            n = Readn(client_sock, &received_packet, received_packet_size);
	        printf("Total de la estructura leida %i y es total leido del archivo %i\n", n, received_packet.size);
	        j += 1024 ;
	        fwrite(received_packet.fileBuff, 1,received_packet.size,fp);
        }
        fclose(fp);
        //  ====================================================================
        */
        get_file(client_sock, received_packet,filesize) ; 
	    

	}

    return 0;
}