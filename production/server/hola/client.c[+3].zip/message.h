

struct sync_message 
{
	char filename[1000];
	long int mtime;
	int size;
	unsigned char fileBuff[1024];
};

struct file_sync_message
{
	int empty_directory ;
} ;
